#!/bin/bash

file=$1

echo "`sed -n 2~2p $file`" >> evenfile

echo "`sed -n 1~2p $file`" >> oddfile
