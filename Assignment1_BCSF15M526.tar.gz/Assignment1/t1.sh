#!/bin/bash
IFS=$'\n'file_names=`ls $1`
declare -i num
num=0
for i in ${file_names[*]##*.}
do 
mkdir $1/$i
mv $1/${file_names[num]} $1/$i/
num=$num+1
done
